# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
-keep class com.yatrimitraapp.data.model.** { *; }
-keep class com.google.android.gms.** { *; }
-keep class com.google.maps.** { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**
