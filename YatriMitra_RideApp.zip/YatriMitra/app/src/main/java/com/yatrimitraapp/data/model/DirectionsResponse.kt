package com.yatrimitraapp.data.model

import com.google.gson.annotations.SerializedName

/**
 * Data models for Google Directions API JSON response parsing.
 */

data class DirectionsResponse(
    @SerializedName("status") val status: String,
    @SerializedName("routes") val routes: List<Route>
)

data class Route(
    @SerializedName("overview_polyline") val overviewPolyline: OverviewPolyline,
    @SerializedName("legs") val legs: List<Leg>
)

data class OverviewPolyline(
    @SerializedName("points") val points: String
)

data class Leg(
    @SerializedName("distance") val distance: TextValue,
    @SerializedName("duration") val duration: TextValue,
    @SerializedName("start_address") val startAddress: String,
    @SerializedName("end_address") val endAddress: String
)

data class TextValue(
    @SerializedName("text") val text: String,
    @SerializedName("value") val value: Int
)

/**
 * Simplified ride info extracted from Directions API response.
 */
data class RideInfo(
    val polylinePoints: List<Pair<Double, Double>>, // decoded lat/lng pairs
    val distanceText: String,    // e.g. "4.5 km"
    val durationText: String,    // e.g. "10 mins"
    val startAddress: String,
    val endAddress: String
)
