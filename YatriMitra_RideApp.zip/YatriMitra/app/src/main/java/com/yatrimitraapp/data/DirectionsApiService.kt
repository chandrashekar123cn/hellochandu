package com.yatrimitraapp.data

import com.yatrimitraapp.data.model.DirectionsResponse
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Retrofit interface for the Google Directions REST API.
 * Endpoint: https://maps.googleapis.com/maps/api/directions/json
 */
interface DirectionsApiService {

    @GET("json")
    suspend fun getDirections(
        @Query("origin") origin: String,        // "lat,lng"
        @Query("destination") destination: String,  // "lat,lng"
        @Query("mode") mode: String = "driving",
        @Query("key") apiKey: String
    ): DirectionsResponse

    companion object {
        private const val BASE_URL = "https://maps.googleapis.com/maps/api/directions/"

        /**
         * Creates a singleton Retrofit instance with logging for debug builds.
         */
        fun create(): DirectionsApiService {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(DirectionsApiService::class.java)
        }
    }
}
