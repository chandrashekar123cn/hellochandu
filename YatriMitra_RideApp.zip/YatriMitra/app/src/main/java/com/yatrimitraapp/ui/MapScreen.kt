package com.yatrimitraapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.*
import com.google.maps.android.compose.*
import com.yatrimitraapp.viewmodel.RideUiState
import com.yatrimitraapp.viewmodel.RideViewModel
import kotlinx.coroutines.launch

/**
 * Main map screen composable. Shows a full-screen Google Map with:
 * - User's current location (blue dot via MyLocation)
 * - Pickup marker (Green)
 * - Drop marker (Red)
 * - Route polyline
 * - Moving driver/vehicle marker
 * - Bottom sheet overlay with ride details
 * - Top instruction banner
 */
@Composable
fun MapScreen(viewModel: RideViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val userLocation by viewModel.userLocation.collectAsStateWithLifecycle()
    val pickupLocation by viewModel.pickupLocation.collectAsStateWithLifecycle()
    val dropLocation by viewModel.dropLocation.collectAsStateWithLifecycle()
    val rideInfo by viewModel.rideInfo.collectAsStateWithLifecycle()
    val driverPosition by viewModel.driverPosition.collectAsStateWithLifecycle()

    // Default camera position (India center), updated on location load
    val defaultLatLng = LatLng(20.5937, 78.9629)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultLatLng, 5f)
    }

    val coroutineScope = rememberCoroutineScope()

    // Animate camera to user location when it first loads
    LaunchedEffect(userLocation) {
        userLocation?.let { loc ->
            cameraPositionState.animate(
                CameraUpdateFactory.newLatLngZoom(loc, 15f),
                durationMs = 1200
            )
        }
    }

    // Zoom to fit full route when route is ready
    LaunchedEffect(rideInfo) {
        rideInfo?.let { info ->
            if (info.polylinePoints.isNotEmpty()) {
                val boundsBuilder = LatLngBounds.Builder()
                info.polylinePoints.forEach { (lat, lng) ->
                    boundsBuilder.include(LatLng(lat, lng))
                }
                val bounds = boundsBuilder.build()
                coroutineScope.launch {
                    cameraPositionState.animate(
                        CameraUpdateFactory.newLatLngBounds(bounds, 120),
                        durationMs = 1000
                    )
                }
            }
        }
    }

    // Follow driver during simulation
    LaunchedEffect(driverPosition) {
        driverPosition?.let { pos ->
            if (uiState is RideUiState.DriverSimulating) {
                cameraPositionState.animate(
                    CameraUpdateFactory.newLatLng(pos),
                    durationMs = 150
                )
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ---- Full-screen Google Map ----
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(
                isMyLocationEnabled = userLocation != null,
                mapType = MapType.NORMAL
            ),
            uiSettings = MapUiSettings(
                zoomControlsEnabled = false,
                myLocationButtonEnabled = true,
                compassEnabled = true
            ),
            onMapClick = { latLng ->
                // Ignore taps during simulation
                if (uiState !is RideUiState.DriverSimulating &&
                    uiState !is RideUiState.RideConfirmed
                ) {
                    viewModel.onMapTap(latLng)
                }
            }
        ) {
            // Pickup marker (Green)
            pickupLocation?.let { pickup ->
                Marker(
                    state = MarkerState(position = pickup),
                    title = "Pickup",
                    snippet = "Your pickup location",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
                )
            }

            // Drop marker (Red)
            dropLocation?.let { drop ->
                Marker(
                    state = MarkerState(position = drop),
                    title = "Drop",
                    snippet = "Your destination",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)
                )
            }

            // Route polyline — drawn from decoded Directions API points
            rideInfo?.let { info ->
                val polylineLatLngs = info.polylinePoints.map { (lat, lng) -> LatLng(lat, lng) }
                if (polylineLatLngs.isNotEmpty()) {
                    Polyline(
                        points = polylineLatLngs,
                        color = Color(0xFF1A73E8),  // Google Maps blue
                        width = 12f,
                        geodesic = true
                    )
                }
            }

            // Driver/vehicle simulation marker (bike icon — yellow marker for now)
            // In production, replace with a custom BitmapDescriptor from a vector asset
            driverPosition?.let { pos ->
                Marker(
                    state = MarkerState(position = pos),
                    title = "Driver",
                    snippet = "Your driver",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW),
                    zIndex = 1f
                )
            }
        }

        // ---- Instruction banner at top ----
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(top = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            MapInstructionBanner(uiState = uiState)
        }

        // ---- Bottom sheet overlay ----
        val showBottomSheet = uiState is RideUiState.WaitingForDrop ||
            uiState is RideUiState.FetchingRoute ||
            uiState is RideUiState.RouteReady ||
            uiState is RideUiState.RideConfirmed ||
            uiState is RideUiState.DriverSimulating

        if (showBottomSheet) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
            ) {
                RideBottomSheet(
                    rideInfo = rideInfo,
                    uiState = uiState,
                    pickupLabel = rideInfo?.startAddress
                        ?: pickupLocation?.let { "${String.format("%.4f", it.latitude)}, ${String.format("%.4f", it.longitude)}" }
                        ?: "",
                    dropLabel = rideInfo?.endAddress
                        ?: dropLocation?.let { "${String.format("%.4f", it.latitude)}, ${String.format("%.4f", it.longitude)}" }
                        ?: "Tap map to set drop",
                    onConfirmRide = { viewModel.confirmRide() },
                    onReset = { viewModel.resetRide() }
                )
            }
        }
    }
}
