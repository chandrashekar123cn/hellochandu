package com.yatrimitraapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yatrimitraapp.data.model.RideInfo
import com.yatrimitraapp.viewmodel.RideUiState

// Brand colors
val YatriGreen = Color(0xFF1DB954)
val YatriDark = Color(0xFF1A1A2E)
val YatriGray = Color(0xFFF5F5F5)
val YatriTextGray = Color(0xFF757575)

/**
 * Bottom sheet UI that appears once a route is available.
 * Shows pickup/drop addresses, ETA, distance, and the Confirm Ride button.
 */
@Composable
fun RideBottomSheet(
    rideInfo: RideInfo?,
    uiState: RideUiState,
    pickupLabel: String,
    dropLabel: String,
    onConfirmRide: () -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
        color = Color.White,
        shadowElevation = 16.dp,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            // Drag handle
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .background(Color(0xFFE0E0E0), RoundedCornerShape(2.dp))
                    .align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Your Ride",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = YatriDark
                )
                if (uiState !is RideUiState.DriverSimulating) {
                    TextButton(onClick = onReset) {
                        Text("Reset", color = Color(0xFFE53935))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ETA and Distance row (if route available)
            if (rideInfo != null) {
                EtaDistanceRow(
                    eta = rideInfo.durationText,
                    distance = rideInfo.distanceText
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Location rows
            LocationRow(
                icon = Icons.Filled.RadioButtonChecked,
                iconColor = YatriGreen,
                label = "Pickup",
                address = pickupLabel
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Dotted connector line
            Box(
                modifier = Modifier
                    .padding(start = 11.dp)
                    .width(2.dp)
                    .height(20.dp)
                    .background(Color(0xFFBDBDBD))
            )

            Spacer(modifier = Modifier.height(4.dp))

            LocationRow(
                icon = Icons.Filled.LocationOn,
                iconColor = Color(0xFFE53935),
                label = "Drop",
                address = dropLabel
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Action button
            when (uiState) {
                is RideUiState.RouteReady -> {
                    ConfirmButton(
                        text = "Confirm Ride",
                        onClick = onConfirmRide,
                        color = YatriGreen
                    )
                }
                is RideUiState.FetchingRoute -> {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = YatriGreen)
                    }
                }
                is RideUiState.RideConfirmed, is RideUiState.DriverSimulating -> {
                    ConfirmButton(
                        text = "Driver On the Way...",
                        onClick = {},
                        color = Color(0xFFFF8C00),
                        enabled = false
                    )
                }
                else -> Unit
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

/**
 * Shows a green/teal pill with ETA and distance info — like Uber/Ola.
 */
@Composable
fun EtaDistanceRow(eta: String, distance: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFE8F5E9), RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        EtaChip(icon = Icons.Filled.AccessTime, label = "ETA", value = eta)
        Divider(
            modifier = Modifier
                .height(28.dp)
                .width(1.dp),
            color = Color(0xFFA5D6A7)
        )
        EtaChip(icon = Icons.Filled.Straighten, label = "Distance", value = distance)
    }
}

@Composable
fun EtaChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = YatriGreen,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(
                text = label,
                fontSize = 10.sp,
                color = YatriTextGray,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = YatriDark
            )
        }
    }
}

/**
 * A single location row showing an icon, label, and address.
 */
@Composable
fun LocationRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    label: String,
    address: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = iconColor,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = label,
                fontSize = 11.sp,
                color = YatriTextGray,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = address.ifBlank { "Tap on map to set $label" },
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = YatriDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Primary action button styled like Uber/Ola.
 */
@Composable
fun ConfirmButton(
    text: String,
    onClick: () -> Unit,
    color: Color,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            disabledContainerColor = color.copy(alpha = 0.6f)
        )
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

/**
 * Instruction overlay shown at the top of the map.
 */
@Composable
fun MapInstructionBanner(uiState: RideUiState) {
    val message = when (uiState) {
        is RideUiState.WaitingForPickup -> "Tap on the map to set Pickup"
        is RideUiState.WaitingForDrop -> "Tap on the map to set Drop"
        is RideUiState.FetchingRoute -> "Fetching route..."
        is RideUiState.DriverSimulating -> "Driver is on the way!"
        is RideUiState.RideConfirmed -> "Ride confirmed!"
        is RideUiState.Error -> (uiState as RideUiState.Error).message
        else -> null
    }

    if (message != null) {
        Surface(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(24.dp),
            color = YatriDark.copy(alpha = 0.85f),
            shadowElevation = 4.dp
        ) {
            Text(
                text = message,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
