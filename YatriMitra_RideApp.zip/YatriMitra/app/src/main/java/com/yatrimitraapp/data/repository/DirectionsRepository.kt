package com.yatrimitraapp.data.repository

import com.google.android.gms.maps.model.LatLng
import com.yatrimitraapp.data.DirectionsApiService
import com.yatrimitraapp.data.model.RideInfo
import com.yatrimitraapp.utils.PolylineDecoder

/**
 * Repository that fetches route data from Google Directions API.
 * Follows Clean Architecture — ViewModel never touches API directly.
 */
class DirectionsRepository(
    private val apiService: DirectionsApiService = DirectionsApiService.create()
) {

    /**
     * Fetches a driving route between two LatLng points.
     * Returns a [RideInfo] with decoded polyline points, distance, and ETA.
     *
     * @param origin       Pickup LatLng
     * @param destination  Drop LatLng
     * @param apiKey       Google Maps API key
     */
    suspend fun getRoute(
        origin: LatLng,
        destination: LatLng,
        apiKey: String
    ): Result<RideInfo> {
        return try {
            val originStr = "${origin.latitude},${origin.longitude}"
            val destStr = "${destination.latitude},${destination.longitude}"

            val response = apiService.getDirections(
                origin = originStr,
                destination = destStr,
                apiKey = apiKey
            )

            if (response.status != "OK" || response.routes.isEmpty()) {
                return Result.failure(Exception("Directions API returned: ${response.status}"))
            }

            val route = response.routes.first()
            val leg = route.legs.firstOrNull()
                ?: return Result.failure(Exception("No route leg found"))

            // Decode the encoded polyline string to a list of lat/lng pairs
            val decodedPoints = PolylineDecoder.decode(route.overviewPolyline.points)

            val rideInfo = RideInfo(
                polylinePoints = decodedPoints,
                distanceText = leg.distance.text,
                durationText = leg.duration.text,
                startAddress = leg.startAddress,
                endAddress = leg.endAddress
            )

            Result.success(rideInfo)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
