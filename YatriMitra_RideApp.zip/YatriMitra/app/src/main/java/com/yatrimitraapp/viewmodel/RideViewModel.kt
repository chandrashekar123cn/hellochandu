package com.yatrimitraapp.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.maps.model.LatLng
import com.yatrimitraapp.data.model.RideInfo
import com.yatrimitraapp.data.repository.DirectionsRepository
import com.yatrimitraapp.utils.LocationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Sealed class representing all possible states of the map/ride UI.
 */
sealed class RideUiState {
    object Idle : RideUiState()
    object LoadingLocation : RideUiState()
    object WaitingForPickup : RideUiState()
    object WaitingForDrop : RideUiState()
    object FetchingRoute : RideUiState()
    data class RouteReady(val rideInfo: RideInfo) : RideUiState()
    object RideConfirmed : RideUiState()
    data class DriverSimulating(val currentPosition: LatLng, val progress: Float) : RideUiState()
    data class Error(val message: String) : RideUiState()
}

/**
 * ViewModel that manages all ride logic including location, route fetching,
 * and driver simulation. Survives screen rotation via AndroidViewModel.
 */
class RideViewModel(application: Application) : AndroidViewModel(application) {

    // Replace with your actual Google Maps API key
    // In production, store this securely (e.g., local.properties or BuildConfig)
    private val apiKey: String = "YOUR_GOOGLE_MAPS_API_KEY_HERE"

    private val locationHelper = LocationHelper(application)
    private val directionsRepository = DirectionsRepository()

    // --- StateFlows (observed by UI) ---

    private val _uiState = MutableStateFlow<RideUiState>(RideUiState.Idle)
    val uiState: StateFlow<RideUiState> = _uiState.asStateFlow()

    private val _userLocation = MutableStateFlow<LatLng?>(null)
    val userLocation: StateFlow<LatLng?> = _userLocation.asStateFlow()

    private val _pickupLocation = MutableStateFlow<LatLng?>(null)
    val pickupLocation: StateFlow<LatLng?> = _pickupLocation.asStateFlow()

    private val _dropLocation = MutableStateFlow<LatLng?>(null)
    val dropLocation: StateFlow<LatLng?> = _dropLocation.asStateFlow()

    private val _rideInfo = MutableStateFlow<RideInfo?>(null)
    val rideInfo: StateFlow<RideInfo?> = _rideInfo.asStateFlow()

    // Current simulated driver position along the route
    private val _driverPosition = MutableStateFlow<LatLng?>(null)
    val driverPosition: StateFlow<LatLng?> = _driverPosition.asStateFlow()

    private var simulationJob: Job? = null

    /**
     * Loads the device's current GPS location.
     * Called after permissions are granted.
     */
    fun loadCurrentLocation() {
        viewModelScope.launch {
            _uiState.value = RideUiState.LoadingLocation
            try {
                val location = locationHelper.getCurrentLocation()
                val latLng = LatLng(location.latitude, location.longitude)
                _userLocation.value = latLng
                _uiState.value = RideUiState.WaitingForPickup
            } catch (e: Exception) {
                Log.e("RideViewModel", "Location error: ${e.message}")
                _uiState.value = RideUiState.Error("Could not get location: ${e.message}")
            }
        }
    }

    /**
     * Handles a map tap. First tap sets pickup, second sets drop.
     * After drop is set, automatically fetches the route.
     */
    fun onMapTap(latLng: LatLng) {
        when {
            _pickupLocation.value == null -> {
                _pickupLocation.value = latLng
                _uiState.value = RideUiState.WaitingForDrop
            }
            _dropLocation.value == null -> {
                _dropLocation.value = latLng
                fetchRoute()
            }
            else -> {
                // Allow resetting by tapping again after route is shown
                resetRide()
                _pickupLocation.value = latLng
                _uiState.value = RideUiState.WaitingForDrop
            }
        }
    }

    /**
     * Fetches the driving route between pickup and drop using the Directions API.
     */
    private fun fetchRoute() {
        val pickup = _pickupLocation.value ?: return
        val drop = _dropLocation.value ?: return

        viewModelScope.launch {
            _uiState.value = RideUiState.FetchingRoute
            val result = directionsRepository.getRoute(pickup, drop, apiKey)
            result.onSuccess { info ->
                _rideInfo.value = info
                _uiState.value = RideUiState.RouteReady(info)
            }.onFailure { e ->
                Log.e("RideViewModel", "Route error: ${e.message}")
                _uiState.value = RideUiState.Error("Could not fetch route: ${e.message}")
            }
        }
    }

    /**
     * Confirms the ride and starts the driver simulation animation.
     * The "driver" (bike icon) moves smoothly along each polyline point.
     */
    fun confirmRide() {
        val info = _rideInfo.value ?: return
        if (info.polylinePoints.isEmpty()) return

        _uiState.value = RideUiState.RideConfirmed
        startDriverSimulation(info)
    }

    /**
     * Animates the driver marker along the decoded polyline route.
     * Each step introduces a small delay to create smooth motion.
     */
    private fun startDriverSimulation(info: RideInfo) {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            val points = info.polylinePoints
            points.forEachIndexed { index, point ->
                val latLng = LatLng(point.first, point.second)
                _driverPosition.value = latLng
                val progress = index.toFloat() / points.size.toFloat()
                _uiState.value = RideUiState.DriverSimulating(latLng, progress)
                // Delay between each step — adjust for speed (80ms ≈ smooth movement)
                delay(80L)
            }
            // Simulation finished
            _uiState.value = RideUiState.Idle
        }
    }

    /**
     * Resets all ride state (pickup, drop, route, driver).
     */
    fun resetRide() {
        simulationJob?.cancel()
        _pickupLocation.value = null
        _dropLocation.value = null
        _rideInfo.value = null
        _driverPosition.value = null
        _uiState.value = RideUiState.WaitingForPickup
    }
}
