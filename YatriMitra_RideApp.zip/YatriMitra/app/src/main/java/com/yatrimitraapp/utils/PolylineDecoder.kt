package com.yatrimitraapp.utils

/**
 * Decodes a Google Maps encoded polyline string into a list of (latitude, longitude) pairs.
 *
 * Google uses a compact encoding algorithm for polylines:
 * https://developers.google.com/maps/documentation/utilities/polylinealgorithm
 */
object PolylineDecoder {

    /**
     * Decodes an encoded polyline string.
     * @param encoded The encoded polyline string from the Directions API response.
     * @return A list of Pair<Double, Double> representing (latitude, longitude) coordinates.
     */
    fun decode(encoded: String): List<Pair<Double, Double>> {
        val poly = mutableListOf<Pair<Double, Double>>()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lng = 0

        while (index < len) {
            // Decode latitude
            var b: Int
            var shift = 0
            var result = 0
            do {
                b = encoded[index++].code - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dLat = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lat += dLat

            // Decode longitude
            shift = 0
            result = 0
            do {
                b = encoded[index++].code - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dLng = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lng += dLng

            // Convert from integer to decimal degrees
            val latitude = lat.toDouble() / 1E5
            val longitude = lng.toDouble() / 1E5
            poly.add(Pair(latitude, longitude))
        }

        return poly
    }
}
