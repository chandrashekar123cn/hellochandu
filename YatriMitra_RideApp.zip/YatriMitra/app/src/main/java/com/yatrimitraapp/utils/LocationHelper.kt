package com.yatrimitraapp.utils

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Helper class for accessing the device's current GPS location
 * using the Google Fused Location Provider API.
 */
class LocationHelper(context: Context) {

    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    /**
     * Suspending function that returns the device's current [Location].
     * Must be called with location permissions already granted.
     *
     * @throws SecurityException if location permissions are not granted.
     * @throws Exception if the location cannot be determined.
     */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(): Location {
        val cancellationToken = CancellationTokenSource()

        return suspendCancellableCoroutine { cont ->
            fusedClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                cancellationToken.token
            ).addOnSuccessListener { location ->
                if (location != null) {
                    cont.resume(location)
                } else {
                    // Fallback: try last known location
                    fusedClient.lastLocation.addOnSuccessListener { lastLoc ->
                        if (lastLoc != null) {
                            cont.resume(lastLoc)
                        } else {
                            cont.resumeWithException(Exception("Unable to determine location"))
                        }
                    }.addOnFailureListener { e ->
                        cont.resumeWithException(e)
                    }
                }
            }.addOnFailureListener { e ->
                cont.resumeWithException(e)
            }

            cont.invokeOnCancellation {
                cancellationToken.cancel()
            }
        }
    }
}
