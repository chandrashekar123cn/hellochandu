package com.yatrimitraapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.yatrimitraapp.ui.MapScreen
import com.yatrimitraapp.ui.YatriGreen
import com.yatrimitraapp.viewmodel.RideViewModel

/**
 * Single-activity app entry point.
 * Handles location permission request before showing the map.
 */
class MainActivity : ComponentActivity() {

    // ViewModel survives rotation (AndroidViewModel)
    private val viewModel: RideViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            YatriMitraTheme {
                YatriMitraApp(viewModel = viewModel)
            }
        }
    }
}

/**
 * Root composable that gates the map behind location permission.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun YatriMitraApp(viewModel: RideViewModel) {
    val locationPermissions = rememberMultiplePermissionsState(
        permissions = listOf(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    // When permissions are first granted, load the user's location
    LaunchedEffect(locationPermissions.allPermissionsGranted) {
        if (locationPermissions.allPermissionsGranted) {
            viewModel.loadCurrentLocation()
        }
    }

    when {
        locationPermissions.allPermissionsGranted -> {
            // All good — show the map
            MapScreen(viewModel = viewModel)
        }
        locationPermissions.shouldShowRationale -> {
            // User denied once — explain why we need it
            PermissionRationaleScreen(
                onGrantClick = { locationPermissions.launchMultiplePermissionRequest() }
            )
        }
        else -> {
            // First time — request permission immediately
            LaunchedEffect(Unit) {
                locationPermissions.launchMultiplePermissionRequest()
            }
            PermissionRationaleScreen(
                onGrantClick = { locationPermissions.launchMultiplePermissionRequest() }
            )
        }
    }
}

/**
 * Screen shown when location permission is required but not granted.
 */
@Composable
fun PermissionRationaleScreen(onGrantClick: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = "YatriMitra",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = YatriGreen
            )
            Spacer(modifier = Modifier.padding(8.dp))
            Text(
                text = "We need access to your location to show your position on the map and find nearby rides.",
                fontSize = 15.sp,
                color = Color(0xFF555555),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.padding(16.dp))
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(containerColor = YatriGreen)
            ) {
                Text("Grant Location Access", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// Minimal Composable Column alias for clarity
@Composable
fun Column(
    horizontalAlignment: Alignment.Horizontal,
    modifier: Modifier,
    content: @Composable () -> Unit
) {
    androidx.compose.foundation.layout.Column(
        horizontalAlignment = horizontalAlignment,
        modifier = modifier,
        content = { content() }
    )
}

/**
 * App-wide Material 3 theme.
 */
@Composable
fun YatriMitraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = YatriGreen,
            onPrimary = Color.White,
            background = Color.White,
            surface = Color.White
        ),
        content = content
    )
}
