# YatriMitra Ride App 🚗

A complete Android ride-hailing app built with Kotlin + Jetpack Compose, similar to Uber/Ola/Rapido.

---

## Features

- Full-screen Google Map with live location (blue dot)
- Tap map to set Pickup (green marker) and Drop (red marker)
- Real route drawn via Google Directions API (encoded polyline)
- ETA and Distance from API response (not dummy data)
- Uber-style bottom sheet with Confirm Ride button
- Smooth driver simulation along the route
- MVVM + StateFlow + Clean Architecture
- Location permission handling (Accompanist Permissions)

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Kotlin |
| UI | Jetpack Compose (Material 3) |
| Maps | Google Maps Compose |
| API | Retrofit + OkHttp → Google Directions API |
| State | StateFlow + ViewModel (survives rotation) |
| Architecture | MVVM + Repository pattern |
| Permissions | Accompanist Permissions |

---

## Project Structure

```
app/src/main/java/com/yatrimitraapp/
├── MainActivity.kt               ← Entry point, permission gating
├── ui/
│   ├── MapScreen.kt              ← Full-screen map, markers, polyline
│   └── BottomSheetUI.kt          ← Ride bottom sheet, ETA, confirm button
├── viewmodel/
│   └── RideViewModel.kt          ← StateFlow logic, simulation, route fetch
├── data/
│   ├── DirectionsApiService.kt   ← Retrofit interface for Directions API
│   ├── model/
│   │   └── DirectionsResponse.kt ← JSON model classes
│   └── repository/
│       └── DirectionsRepository.kt ← Calls API, returns RideInfo
└── utils/
    ├── LocationHelper.kt          ← Fused Location Provider wrapper
    └── PolylineDecoder.kt         ← Decodes Google encoded polyline
```

---

## Setup Instructions

### Step 1 — Get a Google Maps API Key

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project (or select existing)
3. Enable these APIs:
   - **Maps SDK for Android**
   - **Directions API**
4. Go to **Credentials → Create Credentials → API Key**
5. (Recommended) Restrict the key to Android apps with package name: `com.yatrimitraapp`

### Step 2 — Add Your API Key

**Option A — local.properties (recommended, keeps key out of source control):**

```
# In local.properties (at project root):
MAPS_API_KEY=AIzaSy...your_key_here...
```

**Option B — Direct replacement (quick testing):**

Open `app/src/main/res/values/google_maps_api.xml` and replace:
```xml
<string name="google_maps_key">YOUR_GOOGLE_MAPS_API_KEY_HERE</string>
```

Also open `app/src/main/java/com/yatrimitraapp/viewmodel/RideViewModel.kt` and replace:
```kotlin
private val apiKey: String = "YOUR_GOOGLE_MAPS_API_KEY_HERE"
```

### Step 3 — Open in Android Studio

1. Unzip the project
2. Open Android Studio → **File → Open** → select the `YatriMitra` folder
3. Wait for Gradle sync to complete
4. Connect an Android device or start an emulator (API 24+)
5. Click **Run ▶**

### Step 4 — Open in VS Code (with Android tools)

1. Install the **Android iOS Emulator** extension in VS Code
2. Install **Kotlin** extension by fwcd
3. Open the `YatriMitra` folder
4. Use the terminal to build:
   ```bash
   ./gradlew assembleDebug
   ```
5. Install the APK on a device:
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

---

## How to Use the App

1. **Launch** → Grant location permission
2. **Tap the map once** → Sets your Pickup point (green marker)
3. **Tap the map again** → Sets your Drop point (red marker)
4. **Route is fetched** automatically from Google Directions API
5. **Bottom sheet** shows ETA, Distance, pickup/drop addresses
6. **Tap "Confirm Ride"** → Watch the driver (yellow marker) animate along the route

---

## Build Commands (Terminal)

```bash
# Debug APK
./gradlew assembleDebug

# Release APK
./gradlew assembleRelease

# Run tests
./gradlew test

# Install on connected device
./gradlew installDebug
```

---

## Notes

- The app requires a real Google API key with **Directions API** enabled.
- The driver simulation uses the decoded polyline from the real API route — it is not a straight line.
- For production, store the API key using Android Keystore or a secrets management solution, never hardcode it.
- Emulators support location simulation via **Extended Controls → Location**.
